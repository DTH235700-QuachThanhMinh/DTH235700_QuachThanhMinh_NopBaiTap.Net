﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_3._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e) {}

        private void button1_Click(object sender, EventArgs e)
        {
            int Thang = int.Parse(textBox1.Text);
            if (Thang >= 3 && Thang <= 5)
            {
                MessageBox.Show("Mua Xuan", " ", MessageBoxButtons.OK);
            }
            else if (Thang >= 6 && Thang <= 8)
            {
                MessageBox.Show("Mua Ha", " ", MessageBoxButtons.OK);
            }
            else if (Thang >= 9 && Thang <= 11)
            {
                MessageBox.Show("Mua Thu", " ", MessageBoxButtons.OK);
            }
            else if (Thang == 12 || Thang == 1 || Thang == 2)
            {
                MessageBox.Show("Mua Dong", " ", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("Thang khong hop le!", " ", MessageBoxButtons.OK);
            }
        }
    }
}
