﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_4._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n;
            if (int.TryParse(textBox1.Text, out n) && n > 0)
            {
                int sum = 0;
                for(int i = 1; i <= n; i++)
                {
                    sum += i * i;
                }
                textBox2.Text = $"S = 1^2 + 2^2 + 3^2 + ... + {n}^2 = {sum}";
            }
            else
            {
                MessageBox.Show("Vui lòng nhập một số nguyên dương hợp lệ.", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
