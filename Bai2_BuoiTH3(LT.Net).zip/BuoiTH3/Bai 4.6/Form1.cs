﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_4._6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int n;
            if (int.TryParse(textBox1.Text, out n) && n > 0)
            {
                double sum = 0;
                for (int i = 1; i <= n; i++)
                {
                    sum += 1.0 / (2 * i - 1);
                }
                textBox2.Text = $"S = 1 + 1/3 + 1/5 + ... + 1/{2 * n - 1} = {sum:F4}";
            }
            else
            {
                MessageBox.Show("Vui lòng nhập một số nguyên dương hợp lệ.", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
