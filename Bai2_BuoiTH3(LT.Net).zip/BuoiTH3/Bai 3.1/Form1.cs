﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Bai_3._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) {}

        private void label2_Click(object sender, EventArgs e) {}

        private void label3_Click(object sender, EventArgs e) {}

        private void button1_Click(object sender, EventArgs e)
        {
            double x = double.Parse(textBox1.Text);
            double f;
            if (x >= 2)
            {
                f = -8 * x * x * x - 12 * x - 1;
            }
            else if (1 < x && x < 2)
            {
                f = x * x - 6 * x - 19;
            }
            else 
            {
                f = 7 * x;
            }
            textBox2 .Text = f.ToString();
        }
    }
}
