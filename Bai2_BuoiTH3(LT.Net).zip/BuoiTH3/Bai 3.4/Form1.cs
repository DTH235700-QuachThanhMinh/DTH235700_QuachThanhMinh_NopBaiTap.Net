﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_3._4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) {}

        private void textBox4_TextChanged(object sender, EventArgs e) {}

        private void button1_Click(object sender, EventArgs e)
        {
            double a = double.Parse(textBox1.Text);   
            double b = double.Parse(textBox2.Text);
            double c = double.Parse(textBox3.Text);
            string kq = " ";
            if (a == 0)
            {
                if (b == 0 && c == 0)
                    kq = "Phuong trinh vo so nghiem";
                else if (b == 0 && c != 0)
                    kq = "Phuong trinh vo nghiem";
                else 
                    kq = "Phuong trinh co  1  nghiem x = " + (- c / b);
            }
            else
            {
                double delta = b * b - 4 * a * c;
                if (delta < 0)
                {
                    kq = "Phuong trinh vo nghiem";
                }
                else if (delta == 0)
                {
                    kq = "Phuong trinh co nghiem kep x1 = x2 = x = " + (- b / (2 * a));
                }
                else
                {
                    double x1 = ((- b - Math.Sqrt(delta)) / (2 * a));
                    double x2 = ((- b + Math.Sqrt(delta)) / (2 * a));
                    kq = "Phuong trinh co 2 nghiem phan biet x1 = " + x1 + ";  x2 = " + x2;
                }
            }
            textBox4.Text = kq.ToString();
        }
    }
}
