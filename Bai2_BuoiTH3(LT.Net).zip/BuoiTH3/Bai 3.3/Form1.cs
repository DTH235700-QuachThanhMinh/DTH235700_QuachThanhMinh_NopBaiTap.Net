﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_3._3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e) {}

        private void button1_Click(object sender, EventArgs e)
        {
            int Ngay = int.Parse(textBox1.Text);
            int Thang = int.Parse(textBox2.Text);
            int Nam = int.Parse(textBox3.Text);
            int SoNgay = 31;
            if (Thang < 1 || Thang > 12)
            {
                MessageBox.Show("Thang khong hop le!", " ", MessageBoxButtons.OK);
                return;
            }

            else if (Thang == 4 || Thang == 6 || Thang == 9 || Thang == 11)
            {
                SoNgay = 30;
            }
            else if (Thang == 2)
            {
                if ((Nam % 400 == 0) || (Nam % 4 == 0 && Nam % 100 != 0))
                    SoNgay = 29;
                else
                    SoNgay = 28;
            }

            if (Ngay < 1 || Ngay > SoNgay)
                MessageBox.Show("Ngay khong hop le!", " ", MessageBoxButtons.OK);
            else
                MessageBox.Show("Ngay hop le!", " ", MessageBoxButtons.OK);
        }
    }
}
