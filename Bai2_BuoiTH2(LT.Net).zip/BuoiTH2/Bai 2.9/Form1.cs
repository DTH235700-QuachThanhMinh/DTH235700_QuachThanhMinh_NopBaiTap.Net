﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai_2._9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            double a = double.Parse(textBox1.Text);
            double b = double.Parse(textBox2.Text);
            double chuvi = (a + b) * 2;
            textBox3.Text = chuvi.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double a = double.Parse(textBox1.Text);
            double b = double.Parse(textBox2.Text);
            double dientich = a * b;
            textBox3.Text = dientich.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double a = double.Parse(textBox1.Text);
            double b = double.Parse(textBox2.Text);
            double duongcheo = Math.Sqrt(a * a + b * b);
            textBox3.Text = duongcheo.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
            this.button6.Click += new System.EventHandler(this.button6_Click);
        }

        private void Form1_Load(object sender, EventArgs e){}
    }
}
