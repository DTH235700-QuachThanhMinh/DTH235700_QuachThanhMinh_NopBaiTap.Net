﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace Bai_2._10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            double a = double.Parse(textBox1.Text);
            double b = double.Parse(textBox2.Text);
            double chuvi = (a + b) * 2;
            MessageBox.Show(chuvi.ToString(), "", MessageBoxButtons.OK);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double a = double.Parse(textBox1.Text);
            double b = double.Parse(textBox2.Text);
            double dientich = a * b;
            MessageBox.Show(dientich.ToString(), "", MessageBoxButtons.OK);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double a = double.Parse(textBox1.Text);
            double b = double.Parse(textBox2.Text);
            double duongcheo = Math.Sqrt(a * a + b * b);
            MessageBox.Show(duongcheo.ToString(), "", MessageBoxButtons.OK);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
            this.button6.Click += new System.EventHandler(this.button6_Click);
        }
    }
}
